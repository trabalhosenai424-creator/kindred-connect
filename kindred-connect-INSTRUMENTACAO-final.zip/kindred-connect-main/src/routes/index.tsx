import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Activity, AlertTriangle, ArrowUpRight, Bell, BookOpen, Boxes, CalendarClock,
  CheckCircle2, ChevronRight, ClipboardCheck, Clock3, FileBarChart2, FileText,
  Gauge, LayoutDashboard, Menu, PackageCheck, Plus, Search, Settings, ShieldAlert,
  SlidersHorizontal, Sparkles, ToolCase, Wrench, X, Zap
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "INSTRUMENTAÇÃO | Astra Foods" },
      { name: "description", content: "Sistema de gestão de instrumentação, calibração e metrologia da Astra Foods." },
    ],
  }),
  component: InstrumentacaoApp,
});

type ModuleKey =
  | "Dashboard" | "Instrumentos" | "Calibração" | "Padrões" | "Certificados"
  | "Manutenção" | "Não Conformidades" | "Movimentações" | "Indicadores"
  | "Relatórios" | "Documentos" | "Alertas" | "Inteligência" | "Configurações";

const nav: { label: ModuleKey; icon: typeof LayoutDashboard }[] = [
  { label: "Dashboard", icon: LayoutDashboard },
  { label: "Instrumentos", icon: Gauge },
  { label: "Calibração", icon: ClipboardCheck },
  { label: "Padrões", icon: Boxes },
  { label: "Certificados", icon: FileText },
  { label: "Manutenção", icon: Wrench },
  { label: "Não Conformidades", icon: ShieldAlert },
  { label: "Movimentações", icon: ArrowUpRight },
  { label: "Indicadores", icon: Activity },
  { label: "Relatórios", icon: FileBarChart2 },
  { label: "Documentos", icon: BookOpen },
  { label: "Alertas", icon: Bell },
  { label: "Inteligência", icon: Sparkles },
  { label: "Configurações", icon: Settings },
];

const instruments = [
  { code: "INS-001", tag: "TAG-TEMP-001", name: "Termômetro Digital", sector: "P&D", status: "Calibrado", due: "18/09/2026", type: "Temperatura" },
  { code: "INS-002", tag: "TAG-PES-014", name: "Balança de Bancada", sector: "Produção", status: "A vencer", due: "12/09/2026", type: "Massa" },
  { code: "INS-003", tag: "TAG-PRE-007", name: "Manômetro", sector: "Utilidades", status: "Calibrado", due: "04/10/2026", type: "Pressão" },
  { code: "INS-004", tag: "TAG-TEMP-009", name: "Termopar", sector: "Câmaras", status: "Vencido", due: "02/09/2026", type: "Temperatura" },
  { code: "INS-005", tag: "TAG-PES-022", name: "Balança Plataforma", sector: "Expedição", status: "Calibrado", due: "21/10/2026", type: "Massa" },
];

const statusClass = (status: string) => status === "Calibrado" ? "ok" : status === "A vencer" ? "warn" : "danger";

function InstrumentacaoApp() {
  const [active, setActive] = useState<ModuleKey>("Dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState<string | null>(null);

  const filtered = useMemo(() => instruments.filter((i) =>
    `${i.code} ${i.tag} ${i.name} ${i.sector} ${i.type}`.toLowerCase().includes(query.toLowerCase())
  ), [query]);

  const selectModule = (module: ModuleKey) => {
    // Navigation state changes synchronously; data can be loaded later by each module.
    setActive(module);
    setNotice(null);
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "open" : "closed"}`}>
        <div className="brand">
          <div className="brand-mark">A</div>
          {sidebarOpen && <div><strong>ASTRA FOODS</strong><span>INSTRUMENTAÇÃO</span></div>}
        </div>
        <div className="workspace"><span className="dot" /> Operação industrial <ChevronRight size={14} /></div>
        <nav className="nav">
          {nav.map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-item ${active === label ? "active" : ""}`} onClick={() => selectModule(label)} title={label}>
              <Icon size={17} strokeWidth={1.9} />
              {sidebarOpen && <span>{label}</span>}
              {label === "Alertas" && sidebarOpen && <b className="nav-badge">4</b>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button className="nav-item"><Settings size={17} />{sidebarOpen && <span>Preferências</span>}</button>
          <div className="user-card">
            <div className="avatar">PD</div>
            {sidebarOpen && <div><strong>P&D / Instrumentação</strong><small>Operador</small></div>}
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="icon-button" onClick={() => setSidebarOpen(v => !v)}><Menu size={19} /></button>
          <div className="breadcrumbs"><span>INSTRUMENTAÇÃO</span><ChevronRight size={14}/><strong>{active}</strong></div>
          <div className="top-actions">
            <div className="search"><Search size={16}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar instrumento, TAG, certificado..." /></div>
            <button className="icon-button"><Bell size={18}/><i /></button>
            <div className="avatar">PD</div>
          </div>
        </header>

        <section className="content">
          {notice && <div className="toast"><CheckCircle2 size={17}/>{notice}<button onClick={() => setNotice(null)}><X size={14}/></button></div>}
          {active === "Dashboard" ? <Dashboard onAction={(message) => setNotice(message)} /> : <ModuleView module={active} filtered={filtered} onAction={(message) => setNotice(message)} />}
        </section>
      </main>
    </div>
  );
}

function Dashboard({ onAction }: { onAction: (s: string) => void }) {
  const cards = [
    { label: "Total de instrumentos", value: "248", sub: "+12 este ano", icon: Gauge, tone: "blue" },
    { label: "Calibrados", value: "219", sub: "88,3% da base", icon: CheckCircle2, tone: "green" },
    { label: "A vencer em 30 dias", value: "17", sub: "Requer atenção", icon: CalendarClock, tone: "purple" },
    { label: "Vencidos", value: "12", sub: "Bloqueio recomendado", icon: AlertTriangle, tone: "red" },
  ];
  return <>
    <div className="page-heading">
      <div><div className="eyebrow">VISÃO OPERACIONAL</div><h1>Dashboard</h1><p>Controle de instrumentos, calibrações e conformidade metrológica.</p></div>
      <button className="primary" onClick={() => onAction("Nova calibração iniciada — dados serão carregados em segundo plano.")}><Plus size={17}/> Nova calibração</button>
    </div>
    <div className="metric-grid">{cards.map(c => <div className="metric-card" key={c.label}><div className={`metric-icon ${c.tone}`}><c.icon size={19}/></div><div><span>{c.label}</span><strong>{c.value}</strong><small>{c.sub}</small></div></div>)}</div>
    <div className="grid-2">
      <section className="panel"><div className="panel-head"><div><h2>Status das calibrações</h2><span>Visão dos últimos 12 meses</span></div><button className="ghost">Ver indicadores <ChevronRight size={15}/></button></div><div className="bars">{[52,68,61,75,64,82,71,88,79,91,84,96].map((v,i)=><div className="bar-col" key={i}><div className="bar" style={{height:`${v}%`}}/><small>{["Out","Nov","Dez","Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set"][i]}</small></div>)}</div></section>
      <section className="panel"><div className="panel-head"><div><h2>Alertas prioritários</h2><span>Exigem acompanhamento</span></div><span className="counter">4</span></div><Alert title="4 instrumentos vencidos" detail="Último vencimento: 02/09/2026" danger/><Alert title="3 certificados pendentes" detail="Aguardando anexação" warn/><Alert title="2 NCs em prazo crítico" detail="Prazo inferior a 7 dias" danger/><Alert title="5 manutenções programadas" detail="Próximas 30 dias" info/></section>
    </div>
    <section className="panel table-panel"><div className="panel-head"><div><h2>Instrumentos com maior prioridade</h2><span>Ordenados por situação metrológica</span></div><button className="ghost">Ver todos <ChevronRight size={15}/></button></div><InstrumentTable rows={instruments.slice(0,4)} /></section>
  </>;
}

function Alert({title,detail,danger,warn,info}:{title:string;detail:string;danger?:boolean;warn?:boolean;info?:boolean}) { return <div className="alert-row"><div className={`alert-icon ${danger?"danger":warn?"warn":"info"}`}>{danger?<AlertTriangle size={16}/>:warn?<Clock3 size={16}/>:<Wrench size={16}/>}</div><div><strong>{title}</strong><span>{detail}</span></div><ChevronRight size={15} className="muted"/></div> }

function ModuleView({ module, filtered, onAction }: { module: ModuleKey; filtered: typeof instruments; onAction: (s: string) => void }) {
  const descriptions: Record<ModuleKey,string> = {
    Dashboard: "", Instrumentos: "Cadastro mestre e acompanhamento dos ativos metrológicos.", Calibração: "Planejamento, execução e aprovação das calibrações.", Padrões: "Padrões de referência, certificados e rastreabilidade.", Certificados: "Central de certificados e documentos de calibração.", Manutenção: "Ordens preventivas e corretivas dos instrumentos.", "Não Conformidades": "Tratamento de falhas, causas e ações corretivas.", Movimentações: "Histórico de origem, destino e responsáveis.", Indicadores: "KPIs de desempenho metrológico e tendências.", Relatórios: "Relatórios operacionais e gerenciais exportáveis.", Documentos: "Procedimentos, manuais, laudos, fotos e evidências.", Alertas: "Pendências e vencimentos que exigem ação.", Inteligência: "OCR, análise de tendências e apoio inteligente à metrologia.", Configurações: "Cadastros auxiliares, critérios, usuários e regras do sistema."
  };
  const generic = module !== "Instrumentos";
  return <>
    <div className="page-heading"><div><div className="eyebrow">MÓDULO</div><h1>{module}</h1><p>{descriptions[module]}</p></div><button className="primary" onClick={() => onAction(`Ação de ${module} registrada. O processamento ocorre sem bloquear a navegação.`)}><Plus size={17}/> Novo registro</button></div>
    {generic ? <div className="module-grid">{["Visão geral","Pendências","Histórico","Configurações do módulo"].map((x,i)=><div className="feature-card" key={x}><div className="feature-number">0{i+1}</div><div><h3>{x}</h3><p>Estrutura pronta para receber dados reais e regras do módulo.</p></div><ChevronRight size={17}/></div>)}</div> : <section className="panel table-panel"><div className="toolbar"><div className="filter"><SlidersHorizontal size={16}/> Filtros</div><span>{filtered.length} registros encontrados</span><button className="ghost">Exportar <ArrowUpRight size={15}/></button></div><InstrumentTable rows={filtered}/></section>}
    <div className="info-banner"><Zap size={17}/><div><strong>Navegação otimizada</strong><span>A tela é exibida imediatamente. Consultas, filtros e atualizações podem ser processados em segundo plano sem travar a navegação.</span></div></div>
  </>;
}

function InstrumentTable({ rows }: { rows: typeof instruments }) { return <div className="table-wrap"><table><thead><tr><th>Código / TAG</th><th>Instrumento</th><th>Setor</th><th>Tipo</th><th>Próxima calibração</th><th>Status</th><th /></tr></thead><tbody>{rows.map(r=><tr key={r.code}><td><strong>{r.code}</strong><span>{r.tag}</span></td><td>{r.name}</td><td>{r.sector}</td><td>{r.type}</td><td>{r.due}</td><td><span className={`status ${statusClass(r.status)}`}><i/>{r.status}</span></td><td><button className="row-more">•••</button></td></tr>)}</tbody></table></div> }
